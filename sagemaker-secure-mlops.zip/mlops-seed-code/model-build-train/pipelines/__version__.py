"""Metadata for the pipelines package."""

__title__ = "pipelines"
__description__ = "pipelines - template package"
__version__ = "0.0.1"
__author__ = "<Your Name>"
__author_email__ = "<your-email@python.org>"
__license__ = "Apache 2.0"
__url__ = "<https://your-website>"
